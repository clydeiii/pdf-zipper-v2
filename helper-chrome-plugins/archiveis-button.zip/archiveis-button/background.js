function cleanUrl(raw) {
  try {
    const u = new URL(raw);
    u.search = "";
    u.hash = "";
    return u.toString();
  } catch {
    return raw;
  }
}

function openArchive(tab) {
  if (tab && tab.url) {
    chrome.tabs.create({ url: "https://archive.is/" + cleanUrl(tab.url) });
  }
}

// Toolbar button and keyboard shortcut (both fire action.onClicked)
chrome.action.onClicked.addListener(openArchive);

// Context menu
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "archive-is",
    title: "Open on Archive.is",
    contexts: ["page", "link"]
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "archive-is") {
    const url = info.linkUrl || tab.url;
    chrome.tabs.create({ url: "https://archive.is/" + cleanUrl(url) });
  }
});
