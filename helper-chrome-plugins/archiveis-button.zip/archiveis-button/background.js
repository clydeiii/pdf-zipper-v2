function cleanUrl(raw) {
  try {
    const u = new URL(raw);
    u.search = "";
    u.hash = "";
    return u.toString();
  } catch {
    return raw;
  }
}

// Open the archive tab directly to the RIGHT of the current tab (not at the
// far end of the tab strip). openerTabId also keeps it in the current tab's
// group and returns focus to the opener when the archive tab is closed.
function openArchive(tab, urlOverride) {
  const url = urlOverride || (tab && tab.url);
  if (!url) return;

  const createProps = { url: "https://archive.is/" + cleanUrl(url) };
  if (tab && typeof tab.index === "number" && tab.index >= 0) {
    createProps.index = tab.index + 1;
  }
  if (tab && typeof tab.id === "number" && tab.id !== chrome.tabs.TAB_ID_NONE) {
    createProps.openerTabId = tab.id;
  }

  chrome.tabs.create(createProps).catch(() => {
    // openerTabId can be rejected for special windows — retry without extras
    chrome.tabs.create({ url: createProps.url });
  });
}

// Toolbar button and keyboard shortcut (both fire action.onClicked)
chrome.action.onClicked.addListener((tab) => openArchive(tab));

// Context menu
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "archive-is",
    title: "Open on Archive.is",
    contexts: ["page", "link"]
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "archive-is") {
    openArchive(tab, info.linkUrl || undefined);
  }
});
