/*
PDF Printer (MV3) - v3.0.0 universal

Capture any webpage as a PDF with Karpathy-aligned metadata and pdf-zipper-v2
filename conventions. Archive.is cleanup runs automatically when relevant.

Flow:
- Trigger: toolbar icon, Ctrl+Shift+Y, or right-click -> Save as PDF
- Works on any http(s) page.
- Extracts title/author/published date from meta tags.
- Sets document.title to extracted headline so CDP embeds it as PDF /Title.
- For archive.is pages: hides archive chrome in print mode + extracts
  the original source URL from the archive header.
- Generates PDF via CDP Page.printToPDF.
- Downloads as <hostname>-<slug>.pdf (aligned with pdf-zipper-v2).
*/

const COMMAND_NAME = "archive_print_pdf"; // kept stable for user's existing keybind
const CONTEXT_MENU_ID = "pdf_printer_context";
const DEBUGGER_PROTOCOL_VERSION = "1.3";

const ARCHIVE_HOSTS = new Set([
  "archive.is",
  "archive.today",
  "archive.ph",
  "archive.md",
  "archive.vn",
  "archive.li",
  "archive.fo",
]);

const busyTabs = new Set();

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function normalizeHost(hostname) {
  return String(hostname || "").toLowerCase().replace(/^www\./, "");
}

function isArchiveUrl(urlStr) {
  try {
    const u = new URL(urlStr);
    if (u.protocol !== "http:" && u.protocol !== "https:") return false;
    return ARCHIVE_HOSTS.has(normalizeHost(u.hostname));
  } catch (_) {
    return false;
  }
}

function isCapturablePage(urlStr) {
  try {
    const u = new URL(urlStr);
    return u.protocol === "http:" || u.protocol === "https:";
  } catch (_) {
    return false;
  }
}

async function getActiveTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs && tabs.length ? tabs[0] : null;
}

/**
 * Normalize editorial abbreviations before slugifying.
 * NYT style uses "A.I." which would slugify to "a-i" (often truncated to "i").
 */
function normalizeAbbreviations(text) {
  return text
    .replace(/\bA\.I\.\b/gi, "AI")
    .replace(/\bU\.S\.A\.\b/gi, "USA")
    .replace(/\bU\.S\.\b/gi, "US")
    .replace(/\bU\.K\.\b/gi, "UK")
    .replace(/\bE\.U\.\b/gi, "EU")
    .replace(/\bD\.C\.\b/gi, "DC")
    .replace(/\bC\.E\.O\.\b/gi, "CEO")
    .replace(/\bC\.T\.O\.\b/gi, "CTO")
    .replace(/\bN\.Y\.\b/gi, "NY")
    .replace(/\bL\.A\.\b/gi, "LA");
}

/**
 * Slugify text for filenames — aligned with pdf-zipper-v2's slugifyTitle()
 */
function slugify(input) {
  if (!input) return "";
  return normalizeAbbreviations(String(input))
    .toLowerCase()
    .replace(/['']/g, "")
    .replace(/&amp;|&/g, " and ")
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "");
}

/**
 * Build filename aligned with pdf-zipper-v2: hostname-slug.pdf
 *
 * For archive.is pages, uses the ORIGINAL article's hostname.
 * For normal pages, uses the current page's hostname.
 */
function buildFilename(meta) {
  let hostname = "";
  // Prefer the original source URL (archive pages), fall back to page URL
  const sourceUrl = meta.ogUrl || meta.pageUrl || "";
  try {
    const u = new URL(sourceUrl);
    hostname = u.hostname.toLowerCase().replace(/^www\./, "");
  } catch (_) {}
  if (!hostname) hostname = "page";

  const titleSlug = slugify(meta.headline || meta.title || "");
  const slug = titleSlug && titleSlug.length >= 5 ? titleSlug : "page";

  let base = `${hostname}-${slug}`;
  // Match pdf-zipper-v2's 100-char cap
  if (base.length > 100) base = base.slice(0, 100).replace(/-+$/g, "");

  return `${base}.pdf`;
}

function flashBadge(text, color, ms = 2000) {
  try {
    chrome.action.setBadgeText({ text });
    chrome.action.setBadgeBackgroundColor({ color });
    setTimeout(() => {
      try {
        chrome.action.setBadgeText({ text: "" });
      } catch (_) {}
    }, ms);
  } catch (_) {}
}

function logError(prefix, err) {
  const message = err instanceof Error ? err.message : String(err);
  const stack = err instanceof Error ? (err.stack || "") : "";
  try {
    console.error(`${prefix} ${message}`, stack);
  } catch (_) {}
}

async function injectPrintCssAndExtractMeta(tabId, pageUrl, isArchive) {
  const results = await chrome.scripting.executeScript({
    target: { tabId, frameIds: [0] },
    world: "MAIN",
    func: (isArchivePage, pageHref) => {
      // Archive.is-specific print CSS: hide archive chrome when printing.
      // Only injected on archive pages; harmless no-op otherwise.
      if (isArchivePage) {
        const css = `
@media print {
  #HEADER, #DIVSHARE, #DIVSHARE2, #SHARE_CLOSEBTN,
  .share, .share2,
  body > div[style*="padding:10px 0"][style*="min-width:1028px"] {
    display: none !important;
    visibility: hidden !important;
  }
  html, body, #SOLID { background: #fff !important; }
  #CONTENT { border: none !important; margin: 0 !important; }
  iframe[src^="chrome-extension://"],
  frame[src^="chrome-extension://"] {
    display: none !important;
    visibility: hidden !important;
  }
}
        `.trim();

        const STYLE_ID = "pdf-printer-archive-style";
        let styleEl = document.getElementById(STYLE_ID);
        if (!styleEl) {
          styleEl = document.createElement("style");
          styleEl.id = STYLE_ID;
          document.documentElement.appendChild(styleEl);
        }
        styleEl.textContent = css;
      }

      // Remove extension-scheme frames so printToPDF never traverses them.
      const frameNodes = document.querySelectorAll(
        'iframe[src^="chrome-extension://"], frame[src^="chrome-extension://"]'
      );
      if (!window.__pdfPrinterRemovedFrames) window.__pdfPrinterRemovedFrames = [];
      for (const el of frameNodes) {
        if (el.parentNode) {
          window.__pdfPrinterRemovedFrames.push({ el, parent: el.parentNode, next: el.nextSibling });
          el.parentNode.removeChild(el);
        }
      }

      // Determine the original source URL.
      // On archive pages: read from the archive header form field or canonical link.
      // On normal pages: use window.location.href.
      let ogUrl = "";
      if (isArchivePage) {
        ogUrl =
          document.querySelector('#HEADER input[name="q"]')?.value ||
          (() => {
            const canon = document.querySelector('link[rel="canonical"]')?.getAttribute("href") || "";
            const idx = canon.indexOf("https://");
            return idx >= 0 ? canon.slice(idx) : canon;
          })() ||
          "";
      }
      if (!ogUrl) {
        ogUrl = pageHref || window.location.href || "";
      }

      // Title extraction: prefer social meta tags, fall back to document.title
      const rawTitle =
        document.querySelector('meta[property="twitter:title"]')?.content ||
        document.querySelector('meta[property="og:title"]')?.content ||
        document.title ||
        "";

      // Split "Headline | Publication" or "Headline - Publication" patterns
      let headline = rawTitle;
      let publication = "";
      if (rawTitle.includes("|")) {
        const parts = rawTitle.split("|").map((s) => s.trim()).filter(Boolean);
        if (parts.length >= 2) {
          headline = parts.slice(0, -1).join(" | ");
          publication = parts[parts.length - 1];
        }
      } else if (rawTitle.includes(" - ")) {
        const parts = rawTitle.split(" - ").map((s) => s.trim()).filter(Boolean);
        if (parts.length >= 2) {
          headline = parts.slice(0, -1).join(" - ");
          publication = parts[parts.length - 1];
        }
      }

      // Extract article metadata for Karpathy knowledge base pattern
      const author =
        document.querySelector('meta[name="author"]')?.content ||
        document.querySelector('meta[property="article:author"]')?.content ||
        document.querySelector('meta[name="byl"]')?.content || // NYT byline
        "";

      const publishDate =
        document.querySelector('meta[property="article:published_time"]')?.content ||
        document.querySelector('meta[name="date"]')?.content ||
        document.querySelector('time[datetime]')?.getAttribute("datetime") ||
        "";

      const description =
        document.querySelector('meta[property="og:description"]')?.content ||
        document.querySelector('meta[name="description"]')?.content ||
        "";

      // Set document.title to headline so CDP Page.printToPDF embeds it as /Title.
      // This is the most reliable way to get PDF metadata via CDP.
      const originalTitle = document.title;
      if (headline && headline !== document.title) {
        document.title = headline;
        if (!window.__pdfPrinterOriginalTitle) {
          window.__pdfPrinterOriginalTitle = originalTitle;
        }
      }

      return {
        ogUrl,
        pageUrl: pageHref,
        title: rawTitle,
        headline,
        publication,
        author,
        publishDate,
        description,
      };
    },
    args: [isArchive, pageUrl],
  });

  return results?.[0]?.result || {};
}

async function restorePageState(tabId) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId, frameIds: [0] },
      world: "MAIN",
      func: () => {
        if (window.__pdfPrinterRemovedFrames) {
          for (const { el, parent, next } of window.__pdfPrinterRemovedFrames) {
            try { parent.insertBefore(el, next); } catch (_) {}
          }
          window.__pdfPrinterRemovedFrames = [];
        }
        if (window.__pdfPrinterOriginalTitle !== undefined) {
          document.title = window.__pdfPrinterOriginalTitle;
          delete window.__pdfPrinterOriginalTitle;
        }
      },
    });
  } catch (_) {}
}

async function downloadPdf(base64Data, filename) {
  const dataUrl = `data:application/pdf;base64,${base64Data}`;
  await chrome.downloads.download({
    url: dataUrl,
    filename,
    conflictAction: "uniquify",
    saveAs: false,
  });
}

async function printTabToPdf(tabId, filename) {
  await chrome.debugger.attach({ tabId }, DEBUGGER_PROTOCOL_VERSION);
  try {
    await chrome.debugger.sendCommand({ tabId }, "Page.enable");
    await chrome.debugger.sendCommand({ tabId }, "Emulation.setEmulatedMedia", { media: "print" });
    await sleep(150);

    const pdf = await chrome.debugger.sendCommand({ tabId }, "Page.printToPDF", {
      landscape: false,
      displayHeaderFooter: false,
      printBackground: true,
      paperWidth: 8.5,
      paperHeight: 11,
      marginTop: 0.4,
      marginBottom: 0.4,
      marginLeft: 0.4,
      marginRight: 0.4,
      scale: 1,
      preferCSSPageSize: false,
    });

    if (!pdf || !pdf.data) throw new Error("Page.printToPDF returned no data");
    await downloadPdf(pdf.data, filename);
  } finally {
    try {
      await chrome.debugger.sendCommand({ tabId }, "Emulation.setEmulatedMedia", { media: "" });
    } catch (_) {}
    try {
      await chrome.debugger.detach({ tabId });
    } catch (_) {}
  }
}

function registerContextMenu() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create(
      {
        id: CONTEXT_MENU_ID,
        title: "Save page as PDF (with metadata)",
        contexts: ["page"],
        documentUrlPatterns: ["http://*/*", "https://*/*"],
      },
      () => {
        if (chrome.runtime.lastError) {
          console.warn("PDF Printer: context menu registration failed:", chrome.runtime.lastError.message);
        }
      }
    );
  });
}

async function run(tab) {
  const targetTab = tab || (await getActiveTab());
  if (!targetTab?.id || !targetTab?.url) {
    flashBadge("?", "#888");
    return;
  }

  if (!isCapturablePage(targetTab.url)) {
    // chrome://, file://, about:blank, etc.
    flashBadge("N/A", "#888");
    return;
  }

  if (busyTabs.has(targetTab.id)) return;

  const isArchive = isArchiveUrl(targetTab.url);

  busyTabs.add(targetTab.id);
  flashBadge("...", "#2196F3", 30000);

  try {
    const meta = await injectPrintCssAndExtractMeta(targetTab.id, targetTab.url, isArchive);
    const filename = buildFilename(meta);
    await printTabToPdf(targetTab.id, filename);
    flashBadge("OK", "#4CAF50");
  } catch (err) {
    flashBadge("ERR", "#F44336", 4000);
    logError("PDF Printer failed:", err);
  } finally {
    await restorePageState(targetTab.id);
    busyTabs.delete(targetTab.id);
  }
}

chrome.commands.onCommand.addListener((command) => {
  if (command !== COMMAND_NAME) return;
  run().catch((err) => logError("Command trigger failed:", err));
});

chrome.action.onClicked.addListener((tab) => {
  run(tab).catch((err) => logError("Action trigger failed:", err));
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== CONTEXT_MENU_ID) return;
  run(tab).catch((err) => logError("Context menu trigger failed:", err));
});

chrome.runtime.onInstalled.addListener(registerContextMenu);
chrome.runtime.onStartup.addListener(registerContextMenu);
registerContextMenu();
