PDF Printer (Chrome Extension) - v3.0.0 universal
==================================================

What it does
------------
Captures any webpage as a PDF with embedded metadata and a clean filename
that matches pdf-zipper-v2's convention (hostname-slug.pdf).

Triggers (all work on any http(s) page):
  Toolbar icon click
  Keyboard shortcut: Ctrl+Shift+Y (Cmd+Shift+Y on Mac)
  Right-click page -> "Save page as PDF (with metadata)"

Metadata embedded in PDF:
- /Title: extracted from og:title / twitter:title / document.title
  (with "Site Name" suffix stripped)
- Author, publish date extracted from standard meta tags when present

Filename convention (aligned with pdf-zipper-v2):
  <hostname>-<title-slug>.pdf
  e.g. nytimes.com-how-ai-is-changing-journalism.pdf
  e.g. arxiv.org-attention-is-all-you-need.pdf

Editorial abbreviations are preserved: "A.I." -> "ai" (not "a-i"),
"U.S." -> "us", "CEO", "CTO", "NY", "LA", etc.

Archive.is bonus
----------------
When printing from archive.is / archive.today / archive.ph / etc.:
- Archive header/footer is hidden in the PDF
- The original source URL is extracted from the archive header and used
  for the filename (so "wsj.com-headline.pdf" not "archive.is-...").

Why it needs 'debugger' permission
----------------------------------
The extension uses Chrome's DevTools Protocol (CDP) to generate PDFs and
control the download filename. Chrome shows a prominent warning when you
install it — that's expected.

Install (unpacked)
------------------
1) Unzip this package somewhere.
2) Open: chrome://extensions
3) Enable "Developer mode" (top right).
4) Click "Load unpacked" and select the folder: archive_pdf_printer/

Change the hotkey
-----------------
chrome://extensions/shortcuts
Find "PDF Printer" and set any key combo you like.

Notes
-----
- Browser Ctrl+P is reserved by Chrome and cannot be overridden by extensions.
  Use Ctrl+Shift+Y (or customize via chrome://extensions/shortcuts) to trigger.
- Does not run on chrome://, file://, or other non-http(s) schemes.
- Final save location depends on your Chrome download settings.
