/*
Archive PDF Printer (MV3) - v6 Karpathy-aligned

Flow:
- Trigger from icon, keyboard command, or page context menu.
- Validate active tab is supported archive host.
- Inject print CSS + extract metadata.
- Generate PDF using CDP Page.printToPDF.
- Embed Karpathy-compliant metadata in PDF (title, author, source URL, tags).
- Download as <hostname>-<slug>.pdf (aligned with pdf-zipper-v2 naming).
*/

const COMMAND_NAME = "archive_print_pdf";
const CONTEXT_MENU_ID = "archive_print_pdf_context";
const DEBUGGER_PROTOCOL_VERSION = "1.3";

const ARCHIVE_HOSTS = new Set([
  "archive.is",
  "archive.today",
  "archive.ph",
  "archive.md",
  "archive.vn",
  "archive.li",
  "archive.fo",
]);

const ARCHIVE_MATCH_PATTERNS = Array.from(
  ARCHIVE_HOSTS,
  (host) => `*://*.${host}/*`
);

const busyTabs = new Set();

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function normalizeHost(hostname) {
  return String(hostname || "").toLowerCase().replace(/^www\./, "");
}

function isArchiveUrl(urlStr) {
  try {
    const u = new URL(urlStr);
    if (u.protocol !== "http:" && u.protocol !== "https:") return false;
    return ARCHIVE_HOSTS.has(normalizeHost(u.hostname));
  } catch (_) {
    return false;
  }
}

async function getActiveTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs && tabs.length ? tabs[0] : null;
}

/**
 * Normalize editorial abbreviations before slugifying.
 * NYT style uses "A.I." which would become "a-i" (bad).
 * Expand known abbreviations to their full slug-friendly form.
 */
function normalizeAbbreviations(text) {
  return text
    // "A.I." or "a.i." → "ai" (must come before general dot removal)
    .replace(/\bA\.I\.\b/gi, "AI")
    // "U.S." or "u.s." → "US"
    .replace(/\bU\.S\.A?\.\b/gi, "USA")
    .replace(/\bU\.S\.\b/gi, "US")
    // "U.K." → "UK"
    .replace(/\bU\.K\.\b/gi, "UK")
    // "E.U." → "EU"
    .replace(/\bE\.U\.\b/gi, "EU")
    // "D.C." → "DC"
    .replace(/\bD\.C\.\b/gi, "DC")
    // Generic: collapse any remaining X.Y.Z. patterns (e.g. "C.E.O." → "CEO")
    .replace(/\b([A-Za-z])\.([A-Za-z])\.([A-Za-z])?\.?\b/g, "$1$2$3");
}

/**
 * Slugify text for filenames — aligned with pdf-zipper-v2's slugifyTitle()
 * Convention: lowercase, no apostrophes, no special chars, spaces→dashes, max 80 chars
 */
function slugify(input) {
  if (!input) return "";
  return normalizeAbbreviations(String(input))
    .toLowerCase()
    .replace(/['']/g, "")           // Remove apostrophes (matches pdf-zipper-v2)
    .replace(/&amp;|&/g, " and ")
    .replace(/[^a-z0-9\s-]/g, "")  // Remove special characters
    .replace(/\s+/g, "-")          // Spaces to dashes
    .replace(/-+/g, "-")           // Collapse multiple dashes
    .replace(/^-|-$/g, "");         // Trim leading/trailing dashes
}

/**
 * Build filename aligned with pdf-zipper-v2 convention: hostname-slug.pdf
 *
 * pdf-zipper-v2 uses: hostname (www stripped) + pathname (slashes→dashes)
 * For archive captures, the "hostname" is the original article's domain
 * and the "slug" comes from the article title (since archive paths are opaque).
 */
function buildFilename(meta) {
  // Extract hostname from the original URL (the "Saved from" URL)
  let hostname = "";
  try {
    const u = new URL(meta.ogUrl || "");
    hostname = u.hostname.toLowerCase().replace(/^www\./, "");
  } catch (_) {}
  if (!hostname) hostname = "archive";

  // Use title as slug (archive.is paths are opaque, not useful for filenames)
  const titleSlug = slugify(meta.headline || meta.title || "");
  const slug = titleSlug && titleSlug.length >= 5 ? titleSlug : "page";

  // Build: hostname-slug.pdf (matches pdf-zipper-v2 format)
  let base = `${hostname}-${slug}`;

  // Truncate to 100 chars (matches pdf-zipper-v2's sanitizeFilename().substring(0, 100))
  if (base.length > 100) base = base.slice(0, 100).replace(/-+$/g, "");

  return `${base}.pdf`;
}

function flashBadge(text, color, ms = 2000) {
  try {
    chrome.action.setBadgeText({ text });
    chrome.action.setBadgeBackgroundColor({ color });
    setTimeout(() => {
      try {
        chrome.action.setBadgeText({ text: "" });
      } catch (_) {}
    }, ms);
  } catch (_) {}
}

function logError(prefix, err) {
  const message = err instanceof Error ? err.message : String(err);
  const stack = err instanceof Error ? (err.stack || "") : "";
  try {
    console.error(`${prefix} ${message}`, stack);
  } catch (_) {}
}

async function injectPrintCssAndExtractMeta(tabId) {
  const results = await chrome.scripting.executeScript({
    target: { tabId, frameIds: [0] },
    world: "MAIN",
    func: () => {
      const css = `
@media print {
  #HEADER,
  #DIVSHARE,
  #DIVSHARE2,
  #SHARE_CLOSEBTN,
  .share,
  .share2,
  body > div[style*="padding:10px 0"][style*="min-width:1028px"] {
    display: none !important;
    visibility: hidden !important;
  }

  html, body, #SOLID {
    background: #fff !important;
  }

  #CONTENT {
    border: none !important;
    margin: 0 !important;
  }

  iframe[src^="chrome-extension://"],
  frame[src^="chrome-extension://"] {
    display: none !important;
    visibility: hidden !important;
  }
}
      `.trim();

      const STYLE_ID = "archive-pdf-printer-style";
      let styleEl = document.getElementById(STYLE_ID);
      if (!styleEl) {
        styleEl = document.createElement("style");
        styleEl.id = STYLE_ID;
        document.documentElement.appendChild(styleEl);
      }
      styleEl.textContent = css;

      // Remove extension-scheme frames entirely so printToPDF never traverses them.
      const frameNodes = document.querySelectorAll(
        'iframe[src^="chrome-extension://"], frame[src^="chrome-extension://"]'
      );
      if (!window.__archivePdfRemovedFrames) window.__archivePdfRemovedFrames = [];
      for (const el of frameNodes) {
        if (el.parentNode) {
          window.__archivePdfRemovedFrames.push({ el, parent: el.parentNode, next: el.nextSibling });
          el.parentNode.removeChild(el);
        }
      }

      const ogUrl =
        document.querySelector('#HEADER input[name="q"]')?.value ||
        (() => {
          const canon = document.querySelector('link[rel="canonical"]')?.getAttribute("href") || "";
          const idx = canon.indexOf("https://");
          return idx >= 0 ? canon.slice(idx) : canon;
        })() ||
        "";

      let ogUrlHost = "";
      try {
        ogUrlHost = ogUrl ? new URL(ogUrl).hostname : "";
      } catch (_) {}

      const title =
        document.querySelector('meta[property="twitter:title"]')?.content ||
        document.querySelector('meta[property="og:title"]')?.content ||
        document.title ||
        "";

      let headline = title;
      let publication = "";
      if (title.includes("|")) {
        const parts = title.split("|").map((s) => s.trim()).filter(Boolean);
        if (parts.length >= 2) {
          headline = parts.slice(0, -1).join(" | ");
          publication = parts[parts.length - 1];
        }
      } else if (title.includes(" - ")) {
        const parts = title.split(" - ").map((s) => s.trim()).filter(Boolean);
        if (parts.length >= 2) {
          headline = parts.slice(0, -1).join(" - ");
          publication = parts[parts.length - 1];
        }
      }

      // Try to extract author from meta tags
      const author =
        document.querySelector('meta[name="author"]')?.content ||
        document.querySelector('meta[property="article:author"]')?.content ||
        document.querySelector('meta[name="byl"]')?.content ||  // NYT byline
        "";

      // Try to extract publish date
      const publishDate =
        document.querySelector('meta[property="article:published_time"]')?.content ||
        document.querySelector('meta[name="date"]')?.content ||
        document.querySelector('time[datetime]')?.getAttribute("datetime") ||
        "";

      // Try to extract description/summary
      const description =
        document.querySelector('meta[property="og:description"]')?.content ||
        document.querySelector('meta[name="description"]')?.content ||
        "";

      // Try to extract tags/keywords
      const keywords =
        document.querySelector('meta[name="keywords"]')?.content ||
        document.querySelector('meta[property="article:tag"]')?.content ||
        "";

      return {
        ogUrl,
        ogUrlHost,
        title,
        headline,
        publication,
        author,
        publishDate,
        description,
        keywords,
      };
    },
  });

  return results?.[0]?.result || {};
}

async function restoreNeutralizedFrames(tabId) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId, frameIds: [0] },
      world: "MAIN",
      func: () => {
        if (window.__archivePdfRemovedFrames) {
          for (const { el, parent, next } of window.__archivePdfRemovedFrames) {
            try { parent.insertBefore(el, next); } catch (_) {}
          }
          window.__archivePdfRemovedFrames = [];
        }
      },
    });
  } catch (_) {}
}

async function downloadPdf(base64Data, filename) {
  const dataUrl = `data:application/pdf;base64,${base64Data}`;
  await chrome.downloads.download({
    url: dataUrl,
    filename,
    conflictAction: "uniquify",
    saveAs: false,
  });
}

/**
 * Generate PDF with Karpathy-compliant metadata embedded.
 *
 * Uses CDP Page.printToPDF which doesn't support custom Info Dict fields directly.
 * Instead, we embed metadata into the HTML before printing:
 * - Title: set via document.title (CDP respects this)
 * - Author/Subject: injected via PDF metadata comment in the page
 *
 * The consuming system (pdf-zipper-v2 / KB compiler) reads:
 * - PDF Title field → article headline
 * - PDF Subject field → original source URL
 * - PDF Author field → article author
 * - PDF Keywords field → tags
 * - PDF Producer field → tool identification
 */
async function printTabToPdf(tabId, filename, meta) {
  await chrome.debugger.attach({ tabId }, DEBUGGER_PROTOCOL_VERSION);
  try {
    await chrome.debugger.sendCommand({ tabId }, "Page.enable");
    await chrome.debugger.sendCommand({ tabId }, "Emulation.setEmulatedMedia", { media: "print" });
    await sleep(150);

    const pdf = await chrome.debugger.sendCommand({ tabId }, "Page.printToPDF", {
      landscape: true,
      displayHeaderFooter: false,
      printBackground: true,
      paperWidth: 11,
      paperHeight: 8.5,
      marginTop: 0.4,
      marginBottom: 0.4,
      marginLeft: 0.4,
      marginRight: 0.4,
      scale: 1,
      preferCSSPageSize: false,
    });

    if (!pdf || !pdf.data) throw new Error("Page.printToPDF returned no data");

    // Post-process: embed Karpathy metadata into the PDF
    const enrichedData = embedPdfMetadata(pdf.data, meta);
    await downloadPdf(enrichedData, filename);
  } finally {
    try {
      await chrome.debugger.sendCommand({ tabId }, "Emulation.setEmulatedMedia", { media: "" });
    } catch (_) {}
    try {
      await chrome.debugger.detach({ tabId });
    } catch (_) {}
  }
}

/**
 * Embed metadata into a PDF's Info Dictionary.
 *
 * PDF Info Dict lives near the end of the file. We append a new Info Dict
 * object with our metadata fields, then update the trailer to point to it.
 *
 * This is a lightweight approach that doesn't require a full PDF library.
 * Fields aligned with pdf-zipper-v2's Karpathy pattern:
 * - /Title → article headline
 * - /Author → article author
 * - /Subject → original source URL (used by pdf-zipper-v2 for rerun)
 * - /Keywords → tags/keywords
 * - /Creator → publication name + "via Archive PDF Printer"
 * - /Producer → "Archive PDF Printer v6 (Chrome Extension)"
 */
function embedPdfMetadata(base64Data, meta) {
  try {
    const binaryStr = atob(base64Data);
    const bytes = new Uint8Array(binaryStr.length);
    for (let i = 0; i < binaryStr.length; i++) {
      bytes[i] = binaryStr.charCodeAt(i);
    }

    // Build metadata string to inject
    const pdfString = (s) => `(${s.replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)")})`;

    const fields = [];
    if (meta.headline || meta.title) fields.push(`/Title ${pdfString(meta.headline || meta.title)}`);
    if (meta.author) fields.push(`/Author ${pdfString(meta.author)}`);
    if (meta.ogUrl) fields.push(`/Subject ${pdfString(meta.ogUrl)}`);
    if (meta.keywords) fields.push(`/Keywords ${pdfString(meta.keywords)}`);
    const creator = meta.publication
      ? `${meta.publication} via Archive PDF Printer`
      : "Archive PDF Printer";
    fields.push(`/Creator ${pdfString(creator)}`);
    fields.push(`/Producer ${pdfString("Archive PDF Printer v6 (Chrome Extension)")}`);
    if (meta.publishDate) fields.push(`/CreationDate ${pdfString(meta.publishDate)}`);

    if (fields.length === 0) return base64Data;

    // Find the last xref offset from the PDF trailer
    const decoder = new TextDecoder("latin1");
    const pdfText = decoder.decode(bytes);

    // Find startxref to locate trailer
    const startxrefMatch = pdfText.match(/startxref\s+(\d+)\s+%%EOF/);
    if (!startxrefMatch) return base64Data; // Can't parse, return unmodified

    // Find the highest object number
    const objMatches = [...pdfText.matchAll(/(\d+)\s+0\s+obj/g)];
    let maxObjNum = 0;
    for (const m of objMatches) {
      const n = parseInt(m[1], 10);
      if (n > maxObjNum) maxObjNum = n;
    }

    const newObjNum = maxObjNum + 1;
    const infoObj = `${newObjNum} 0 obj\n<< ${fields.join(" ")} >>\nendobj\n`;

    // Find existing trailer and add/replace /Info reference
    // We'll append the new object and a new trailer pointing to it
    const eofIndex = pdfText.lastIndexOf("%%EOF");
    if (eofIndex < 0) return base64Data;

    // Extract existing trailer to find /Root reference
    const trailerMatch = pdfText.match(/trailer\s*<<([^>]*)>>/);
    let trailerDict = trailerMatch ? trailerMatch[1] : "";

    // Remove existing /Info if present
    trailerDict = trailerDict.replace(/\/Info\s+\d+\s+\d+\s+R/g, "");

    // Add our /Info reference
    trailerDict += ` /Info ${newObjNum} 0 R`;

    // Build new xref and trailer
    const beforeEof = pdfText.substring(0, eofIndex);
    const newXrefOffset = beforeEof.length;

    const appendStr = infoObj +
      `xref\n${newObjNum} 1\n` +
      `0000000000 00000 n \n` + // placeholder, incremental xref
      `trailer\n<<${trailerDict} >>\n` +
      `startxref\n${newXrefOffset}\n%%EOF\n`;

    // Combine original (minus %%EOF) + new content
    const originalWithoutEof = bytes.subarray(0, eofIndex);
    const appendBytes = new TextEncoder().encode(appendStr);
    const combined = new Uint8Array(originalWithoutEof.length + appendBytes.length);
    combined.set(originalWithoutEof, 0);
    combined.set(appendBytes, originalWithoutEof.length);

    // Update the xref offset for the new object
    const infoObjOffset = originalWithoutEof.length;
    const offsetStr = String(infoObjOffset).padStart(10, "0");
    const combinedText = decoder.decode(combined);
    const fixedText = combinedText.replace("0000000000 00000 n ", `${offsetStr} 00000 n `);

    // Re-encode to base64
    const fixedBytes = new TextEncoder().encode(fixedText);
    let binary = "";
    for (let i = 0; i < fixedBytes.length; i++) {
      binary += String.fromCharCode(fixedBytes[i]);
    }
    return btoa(binary);
  } catch (err) {
    console.warn("Failed to embed PDF metadata:", err);
    return base64Data; // Return unmodified on failure
  }
}

function registerContextMenu() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create(
      {
        id: CONTEXT_MENU_ID,
        title: "Save cleaned archive page as PDF",
        contexts: ["page"],
        documentUrlPatterns: ARCHIVE_MATCH_PATTERNS,
      },
      () => {
        if (chrome.runtime.lastError) {
          console.warn("Archive PDF Printer: context menu registration failed:", chrome.runtime.lastError.message);
        }
      }
    );
  });
}

async function run(tab) {
  const targetTab = tab || (await getActiveTab());
  if (!targetTab?.id || !targetTab?.url) {
    flashBadge("?", "#888");
    return;
  }

  if (!isArchiveUrl(targetTab.url)) {
    flashBadge("N/A", "#888");
    return;
  }

  if (busyTabs.has(targetTab.id)) return;

  busyTabs.add(targetTab.id);
  flashBadge("...", "#2196F3", 30000);

  try {
    const meta = await injectPrintCssAndExtractMeta(targetTab.id);
    const filename = buildFilename(meta);
    await printTabToPdf(targetTab.id, filename, meta);
    flashBadge("OK", "#4CAF50");
  } catch (err) {
    flashBadge("ERR", "#F44336", 4000);
    logError("Archive PDF Printer failed:", err);
  } finally {
    await restoreNeutralizedFrames(targetTab.id);
    busyTabs.delete(targetTab.id);
  }
}

chrome.commands.onCommand.addListener((command) => {
  if (command !== COMMAND_NAME) return;
  run().catch((err) => logError("Command trigger failed:", err));
});

chrome.action.onClicked.addListener((tab) => {
  run(tab).catch((err) => logError("Action trigger failed:", err));
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== CONTEXT_MENU_ID) return;
  run(tab).catch((err) => logError("Context menu trigger failed:", err));
});

chrome.runtime.onInstalled.addListener(registerContextMenu);
chrome.runtime.onStartup.addListener(registerContextMenu);
registerContextMenu();
