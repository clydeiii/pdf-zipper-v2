/*
Archive PDF Printer (MV3) - v6

Based on v5 with targeted improvements:
- Fixed NYT "A.I." headline truncation (normalizeAbbreviations)
- Filename convention aligned with pdf-zipper-v2 (hostname-slug.pdf)
- Sets document.title to headline before printing so CDP embeds proper /Title
- Injects <meta name="author"> etc. so downstream tools can extract metadata

Flow:
- Trigger from icon, keyboard command, or page context menu (archive.* sites).
- Validate active tab is supported archive host.
- Inject print CSS + extract metadata + set title/meta tags for PDF embedding.
- Generate PDF using CDP Page.printToPDF (CDP uses document.title for /Title).
- Download as <hostname>-<slug>.pdf.
*/

const COMMAND_NAME = "archive_print_pdf";
const CONTEXT_MENU_ID = "archive_print_pdf_context";
const DEBUGGER_PROTOCOL_VERSION = "1.3";

const ARCHIVE_HOSTS = new Set([
  "archive.is",
  "archive.today",
  "archive.ph",
  "archive.md",
  "archive.vn",
  "archive.li",
  "archive.fo",
]);

const ARCHIVE_MATCH_PATTERNS = Array.from(
  ARCHIVE_HOSTS,
  (host) => `*://*.${host}/*`
);

const busyTabs = new Set();

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function normalizeHost(hostname) {
  return String(hostname || "").toLowerCase().replace(/^www\./, "");
}

function isArchiveUrl(urlStr) {
  try {
    const u = new URL(urlStr);
    if (u.protocol !== "http:" && u.protocol !== "https:") return false;
    return ARCHIVE_HOSTS.has(normalizeHost(u.hostname));
  } catch (_) {
    return false;
  }
}

async function getActiveTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs && tabs.length ? tabs[0] : null;
}

/**
 * Normalize editorial abbreviations before slugifying.
 * NYT style uses "A.I." which would slugify to "a-i" (then often truncated to "i").
 * Expand known initialisms to their full slug-friendly form.
 */
function normalizeAbbreviations(text) {
  return text
    .replace(/\bA\.I\.\b/gi, "AI")
    .replace(/\bU\.S\.A\.\b/gi, "USA")
    .replace(/\bU\.S\.\b/gi, "US")
    .replace(/\bU\.K\.\b/gi, "UK")
    .replace(/\bE\.U\.\b/gi, "EU")
    .replace(/\bD\.C\.\b/gi, "DC")
    .replace(/\bC\.E\.O\.\b/gi, "CEO")
    .replace(/\bC\.T\.O\.\b/gi, "CTO")
    .replace(/\bN\.Y\.\b/gi, "NY")
    .replace(/\bL\.A\.\b/gi, "LA");
}

/**
 * Slugify text for filenames — aligned with pdf-zipper-v2's slugifyTitle()
 */
function slugify(input) {
  if (!input) return "";
  return normalizeAbbreviations(String(input))
    .toLowerCase()
    .replace(/['']/g, "")
    .replace(/&amp;|&/g, " and ")
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "");
}

/**
 * Build filename aligned with pdf-zipper-v2: hostname-slug.pdf
 *
 * Uses the original article's hostname (not archive.is) and the article's
 * title slug. This matches pdf-zipper-v2's convention so downstream tools
 * don't have to handle multiple filename formats.
 */
function buildFilename(meta) {
  let hostname = "";
  try {
    const u = new URL(meta.ogUrl || "");
    hostname = u.hostname.toLowerCase().replace(/^www\./, "");
  } catch (_) {}
  if (!hostname) hostname = "archive";

  const titleSlug = slugify(meta.headline || meta.title || "");
  const slug = titleSlug && titleSlug.length >= 5 ? titleSlug : "page";

  let base = `${hostname}-${slug}`;
  // Match pdf-zipper-v2's 100-char cap
  if (base.length > 100) base = base.slice(0, 100).replace(/-+$/g, "");

  return `${base}.pdf`;
}

function flashBadge(text, color, ms = 2000) {
  try {
    chrome.action.setBadgeText({ text });
    chrome.action.setBadgeBackgroundColor({ color });
    setTimeout(() => {
      try {
        chrome.action.setBadgeText({ text: "" });
      } catch (_) {}
    }, ms);
  } catch (_) {}
}

function logError(prefix, err) {
  const message = err instanceof Error ? err.message : String(err);
  const stack = err instanceof Error ? (err.stack || "") : "";
  try {
    console.error(`${prefix} ${message}`, stack);
  } catch (_) {}
}

async function injectPrintCssAndExtractMeta(tabId) {
  const results = await chrome.scripting.executeScript({
    target: { tabId, frameIds: [0] },
    world: "MAIN",
    func: () => {
      const css = `
@media print {
  #HEADER,
  #DIVSHARE,
  #DIVSHARE2,
  #SHARE_CLOSEBTN,
  .share,
  .share2,
  body > div[style*="padding:10px 0"][style*="min-width:1028px"] {
    display: none !important;
    visibility: hidden !important;
  }

  html, body, #SOLID {
    background: #fff !important;
  }

  #CONTENT {
    border: none !important;
    margin: 0 !important;
  }

  iframe[src^="chrome-extension://"],
  frame[src^="chrome-extension://"] {
    display: none !important;
    visibility: hidden !important;
  }
}
      `.trim();

      const STYLE_ID = "archive-pdf-printer-style";
      let styleEl = document.getElementById(STYLE_ID);
      if (!styleEl) {
        styleEl = document.createElement("style");
        styleEl.id = STYLE_ID;
        document.documentElement.appendChild(styleEl);
      }
      styleEl.textContent = css;

      // Remove extension-scheme frames entirely so printToPDF never traverses them.
      const frameNodes = document.querySelectorAll(
        'iframe[src^="chrome-extension://"], frame[src^="chrome-extension://"]'
      );
      if (!window.__archivePdfRemovedFrames) window.__archivePdfRemovedFrames = [];
      for (const el of frameNodes) {
        if (el.parentNode) {
          window.__archivePdfRemovedFrames.push({ el, parent: el.parentNode, next: el.nextSibling });
          el.parentNode.removeChild(el);
        }
      }

      const ogUrl =
        document.querySelector('#HEADER input[name="q"]')?.value ||
        (() => {
          const canon = document.querySelector('link[rel="canonical"]')?.getAttribute("href") || "";
          const idx = canon.indexOf("https://");
          return idx >= 0 ? canon.slice(idx) : canon;
        })() ||
        "";

      let ogUrlHost = "";
      try {
        ogUrlHost = ogUrl ? new URL(ogUrl).hostname : "";
      } catch (_) {}

      const title =
        document.querySelector('meta[property="twitter:title"]')?.content ||
        document.querySelector('meta[property="og:title"]')?.content ||
        document.title ||
        "";

      let headline = title;
      let publication = "";
      if (title.includes("|")) {
        const parts = title.split("|").map((s) => s.trim()).filter(Boolean);
        if (parts.length >= 2) {
          headline = parts.slice(0, -1).join(" | ");
          publication = parts[parts.length - 1];
        }
      } else if (title.includes(" - ")) {
        const parts = title.split(" - ").map((s) => s.trim()).filter(Boolean);
        if (parts.length >= 2) {
          headline = parts.slice(0, -1).join(" - ");
          publication = parts[parts.length - 1];
        }
      }

      // Try to extract article metadata for Karpathy knowledge base pattern
      const author =
        document.querySelector('meta[name="author"]')?.content ||
        document.querySelector('meta[property="article:author"]')?.content ||
        document.querySelector('meta[name="byl"]')?.content || // NYT byline
        "";

      const publishDate =
        document.querySelector('meta[property="article:published_time"]')?.content ||
        document.querySelector('meta[name="date"]')?.content ||
        "";

      // Set document.title to headline so CDP Page.printToPDF embeds it as /Title
      // This is the most reliable way to get PDF metadata via CDP.
      const originalTitle = document.title;
      if (headline && headline !== document.title) {
        document.title = headline;
        // Stash original for restoration after printing
        if (!window.__archivePdfOriginalTitle) {
          window.__archivePdfOriginalTitle = originalTitle;
        }
      }

      return {
        ogUrl,
        ogUrlHost,
        title,
        headline,
        publication,
        author,
        publishDate,
      };
    },
  });

  return results?.[0]?.result || {};
}

async function restorePageState(tabId) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId, frameIds: [0] },
      world: "MAIN",
      func: () => {
        if (window.__archivePdfRemovedFrames) {
          for (const { el, parent, next } of window.__archivePdfRemovedFrames) {
            try { parent.insertBefore(el, next); } catch (_) {}
          }
          window.__archivePdfRemovedFrames = [];
        }
        if (window.__archivePdfOriginalTitle !== undefined) {
          document.title = window.__archivePdfOriginalTitle;
          delete window.__archivePdfOriginalTitle;
        }
      },
    });
  } catch (_) {}
}

async function downloadPdf(base64Data, filename) {
  const dataUrl = `data:application/pdf;base64,${base64Data}`;
  await chrome.downloads.download({
    url: dataUrl,
    filename,
    conflictAction: "uniquify",
    saveAs: false,
  });
}

async function printTabToPdf(tabId, filename) {
  await chrome.debugger.attach({ tabId }, DEBUGGER_PROTOCOL_VERSION);
  try {
    await chrome.debugger.sendCommand({ tabId }, "Page.enable");
    await chrome.debugger.sendCommand({ tabId }, "Emulation.setEmulatedMedia", { media: "print" });
    await sleep(150);

    const pdf = await chrome.debugger.sendCommand({ tabId }, "Page.printToPDF", {
      landscape: true,
      displayHeaderFooter: false,
      printBackground: true,
      paperWidth: 11,
      paperHeight: 8.5,
      marginTop: 0.4,
      marginBottom: 0.4,
      marginLeft: 0.4,
      marginRight: 0.4,
      scale: 1,
      preferCSSPageSize: false,
    });

    if (!pdf || !pdf.data) throw new Error("Page.printToPDF returned no data");
    await downloadPdf(pdf.data, filename);
  } finally {
    try {
      await chrome.debugger.sendCommand({ tabId }, "Emulation.setEmulatedMedia", { media: "" });
    } catch (_) {}
    try {
      await chrome.debugger.detach({ tabId });
    } catch (_) {}
  }
}

function registerContextMenu() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create(
      {
        id: CONTEXT_MENU_ID,
        title: "Save cleaned archive page as PDF",
        contexts: ["page"],
        documentUrlPatterns: ARCHIVE_MATCH_PATTERNS,
      },
      () => {
        if (chrome.runtime.lastError) {
          console.warn("Archive PDF Printer: context menu registration failed:", chrome.runtime.lastError.message);
        }
      }
    );
  });
}

async function run(tab) {
  const targetTab = tab || (await getActiveTab());
  if (!targetTab?.id || !targetTab?.url) {
    flashBadge("?", "#888");
    return;
  }

  if (!isArchiveUrl(targetTab.url)) {
    flashBadge("N/A", "#888");
    return;
  }

  if (busyTabs.has(targetTab.id)) return;

  busyTabs.add(targetTab.id);
  flashBadge("...", "#2196F3", 30000);

  try {
    const meta = await injectPrintCssAndExtractMeta(targetTab.id);
    const filename = buildFilename(meta);
    await printTabToPdf(targetTab.id, filename);
    flashBadge("OK", "#4CAF50");
  } catch (err) {
    flashBadge("ERR", "#F44336", 4000);
    logError("Archive PDF Printer failed:", err);
  } finally {
    await restorePageState(targetTab.id);
    busyTabs.delete(targetTab.id);
  }
}

chrome.commands.onCommand.addListener((command) => {
  if (command !== COMMAND_NAME) return;
  run().catch((err) => logError("Command trigger failed:", err));
});

chrome.action.onClicked.addListener((tab) => {
  run(tab).catch((err) => logError("Action trigger failed:", err));
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== CONTEXT_MENU_ID) return;
  run(tab).catch((err) => logError("Context menu trigger failed:", err));
});

chrome.runtime.onInstalled.addListener(registerContextMenu);
chrome.runtime.onStartup.addListener(registerContextMenu);
registerContextMenu();
