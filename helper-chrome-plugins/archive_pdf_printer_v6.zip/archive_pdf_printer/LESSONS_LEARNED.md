# Lessons Learned

## Reliability and Triggering
- Add multiple trigger paths for MV3 service workers: toolbar icon, command shortcut, and right-click context menu.
- Context menus are the most reliable user-facing fallback when shortcuts fail or are not bound.
- Register context menus on `onInstalled`, `onStartup`, and at worker load to reduce missing-menu edge cases.

## Host Matching and URL Patterns
- Archive pages can appear on `www` subdomains; normalize host checks before matching.
- Context menu `documentUrlPatterns` should include subdomains (for example `*://*.archive.is/*`) to avoid silent non-matches.

## Service Worker Debugging
- If all triggers fail, suspect worker load failure first, not trigger logic.
- First check should be `chrome://extensions` -> extension card -> Service Worker errors.
- Keep error handling and logs in `background.js` explicit so worker-console diagnosis is fast.

## Packaging Discipline
- Always rezip after any code change before moving to prod machine.
- Keep archive naming versioned (for example `archive_pdf_printer_v4.zip`) for traceability.
