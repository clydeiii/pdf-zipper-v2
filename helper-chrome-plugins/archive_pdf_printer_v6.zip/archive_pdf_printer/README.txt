Archive PDF Printer (Chrome Extension) - v5 clean rebuild
======================================

What it does
------------
When you are viewing an archive.is / archive.today snapshot, use any of:

  Right-click page -> "Save cleaned archive page as PDF"
  Windows/Linux:  Ctrl + Shift + Y
  macOS:          Command + Shift + Y

The extension will:
1) Hide the archive header/footer UI in *print* mode (so the on-screen view stays the same).
2) Generate a PDF via Chrome's DevTools Protocol (CDP Page.printToPDF).
3) Download it with an auto-generated filename like:

    wired-made-in-china-niche-websites-are-seeing-a-surge-of-mysterious-traffic-from-china.pdf

Filename rules:
- no spaces (lowercase, hyphen-separated)
- based on the original ("Saved from") URL when available
- falls back to the page title otherwise

Why it asks for powerful permission
-----------------------------------
This extension uses the 'debugger' permission so it can create a PDF and control the download filename.
Chrome will show a prominent warning when you install it. That is expected.

Install (unpacked)
------------------
1) Unzip this package somewhere.
2) Open: chrome://extensions
3) Enable "Developer mode" (top right).
4) Click "Load unpacked" and select the folder: archive_pdf_printer/

Change the hotkey
-----------------
chrome://extensions/shortcuts
Find "Archive PDF Printer" and set any key combo you like.

Troubleshooting
---------------
If icon click, hotkey, and right-click all fail, the service worker likely is not loading.
Check `chrome://extensions` -> Archive PDF Printer -> "Service worker" and inspect errors.

Notes / limitations
-------------------
- The extension only runs on archive.* pages.
- The final save location depends on your Chrome download settings (and whether "Ask where to save each file" is enabled).
