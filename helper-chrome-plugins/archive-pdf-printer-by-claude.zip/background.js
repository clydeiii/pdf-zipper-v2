chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.id || !tab.url) return;

  // Skip chrome:// and other internal pages
  if (!tab.url.startsWith('http')) return;

  try {
    await chrome.tabs.sendMessage(tab.id, { action: 'print' });
  } catch (e) {
    // Content script not loaded yet — inject it, then print
    try {
      await chrome.scripting.insertCSS({
        target: { tabId: tab.id },
        files: ['print.css']
      });
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['content.js']
      });
      // Give it a moment to initialize, then send
      setTimeout(() => {
        chrome.tabs.sendMessage(tab.id, { action: 'print' });
      }, 100);
    } catch (e2) {
      // Can't inject (e.g. chrome web store pages)
    }
  }
});
