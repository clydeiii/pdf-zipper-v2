(() => {
  'use strict';

  // Prevent double-initialization if injected twice
  if (window.__pdfArchiverLoaded) return;
  window.__pdfArchiverLoaded = true;

  // =========================================================
  // Publication name mappings
  // =========================================================
  const PUBLICATION_MAP = {
    'wsj.com': 'wallstreetjournal',
    'nytimes.com': 'newyorktimes',
    'nyt.com': 'newyorktimes',
    'washingtonpost.com': 'washingtonpost',
    'wired.com': 'wired',
    'arstechnica.com': 'arstechnica',
    'theverge.com': 'theverge',
    'bbc.com': 'bbc',
    'bbc.co.uk': 'bbc',
    'cnn.com': 'cnn',
    'ft.com': 'financialtimes',
    'economist.com': 'economist',
    'theguardian.com': 'theguardian',
    'guardian.co.uk': 'theguardian',
    'bloomberg.com': 'bloomberg',
    'reuters.com': 'reuters',
    'apnews.com': 'apnews',
    'latimes.com': 'latimes',
    'sfchronicle.com': 'sfchronicle',
    'sfgate.com': 'sfgate',
    'nypost.com': 'nypost',
    'dailymail.co.uk': 'dailymail',
    'telegraph.co.uk': 'telegraph',
    'thetimes.co.uk': 'thetimes',
    'theatlantic.com': 'theatlantic',
    'newyorker.com': 'newyorker',
    'politico.com': 'politico',
    'thehill.com': 'thehill',
    'axios.com': 'axios',
    'vox.com': 'vox',
    'slate.com': 'slate',
    'salon.com': 'salon',
    'thedailybeast.com': 'thedailybeast',
    'buzzfeed.com': 'buzzfeed',
    'huffpost.com': 'huffpost',
    'techcrunch.com': 'techcrunch',
    'engadget.com': 'engadget',
    'zdnet.com': 'zdnet',
    'vice.com': 'vice',
    'rollingstone.com': 'rollingstone',
    'vanityfair.com': 'vanityfair',
    'forbes.com': 'forbes',
    'businessinsider.com': 'businessinsider',
    'insider.com': 'insider',
    'cnbc.com': 'cnbc',
    'nbcnews.com': 'nbcnews',
    'abcnews.go.com': 'abcnews',
    'cbsnews.com': 'cbsnews',
    'foxnews.com': 'foxnews',
    'msnbc.com': 'msnbc',
    'usatoday.com': 'usatoday',
    'time.com': 'time',
    'nature.com': 'nature',
    'sciencemag.org': 'science',
    'scientificamerican.com': 'scientificamerican',
    'nationalgeographic.com': 'nationalgeographic',
    'propublica.org': 'propublica',
    'theintercept.com': 'theintercept',
    'motherjones.com': 'motherjones',
    'reason.com': 'reason',
    'jacobin.com': 'jacobin',
    'defenseone.com': 'defenseone',
    'foreignaffairs.com': 'foreignaffairs',
    'foreignpolicy.com': 'foreignpolicy',
    'substack.com': 'substack',
    'medium.com': 'medium',
    'theinformation.com': 'theinformation',
    'semafor.com': 'semafor',
    'punchbowl.news': 'punchbowl',
    'thedispatch.com': 'thedispatch',
    'lawfaremedia.org': 'lawfare',
    'theregister.com': 'theregister',
    'aei.org': 'aei',
    'brookings.edu': 'brookings',
    'heritage.org': 'heritage',
    'cato.org': 'cato',
  };

  // Stop words stripped from headline slugs
  const STOP_WORDS = new Set([
    'a', 'an', 'the', 'is', 'are', 'was', 'were', 'be', 'been', 'being',
    'has', 'have', 'had', 'do', 'does', 'did', 'will', 'would', 'could',
    'should', 'may', 'might', 'shall', 'can', 'its', 'it', 'this', 'that',
    'these', 'those', 'am', 'or', 'but', 'if', 'not', 'no', 'nor',
    'so', 'yet', 'both', 'each', 'than', 'too', 'very', 'just',
    'about', 'also', 'into', 'only',
  ]);

  // =========================================================
  // Helpers
  // =========================================================

  function isArchiveSite() {
    return /^archive\.(is|today|ph|li|vn|fo|md)$/.test(location.hostname);
  }

  /** On archive.is, extract the original URL buried in the page */
  function getOriginalUrl() {
    if (!isArchiveSite()) return '';

    // canonical link: https://archive.is/YYYY.MM.DD-HHMMSS/https://original.url
    const canonical = document.querySelector('link[rel="canonical"]');
    if (canonical) {
      const m = canonical.href.match(/archive\.[^/]+\/[\d.]+-\d+\/(https?:\/\/.+)/);
      if (m) return m[1];
    }

    // bookmark link: http://archive.today/YYYYMMDDHHMMSS/https://original.url
    const bookmark = document.querySelector('link[rel="bookmark"]');
    if (bookmark) {
      const m = bookmark.href.match(/archive\.[^/]+\/\d+\/(https?:\/\/.+)/);
      if (m) return m[1];
    }

    // search input in the archive.is header
    const input = document.querySelector('#HEADER input[name="q"]');
    if (input && input.value) return input.value;

    return '';
  }

  /** Map hostname → publication slug */
  function hostnameToPublication(hostname) {
    hostname = hostname.replace(/^www\./, '');

    // Direct lookup
    if (PUBLICATION_MAP[hostname]) return PUBLICATION_MAP[hostname];

    // Try parent domain (e.g., news.bbc.co.uk → bbc.co.uk)
    const parts = hostname.split('.');
    if (parts.length > 2) {
      const parent = parts.slice(-2).join('.');
      if (PUBLICATION_MAP[parent]) return PUBLICATION_MAP[parent];

      // co.uk / com.au style TLDs
      const secondLast = parts[parts.length - 2];
      if (secondLast.length <= 3) {
        const grandparent = parts.slice(-3).join('.');
        if (PUBLICATION_MAP[grandparent]) return PUBLICATION_MAP[grandparent];
      }
    }

    // Fallback: domain name without TLD, stripped of non-alphanumeric
    const tldParts = (parts[parts.length - 2]?.length <= 3 && parts[parts.length - 1].length <= 3) ? 2 : 1;
    return parts.slice(0, -tldParts).join('').replace(/[^a-z0-9]/gi, '').toLowerCase();
  }

  /** Determine the publication name for the current page */
  function getPublication() {
    // On archive.is, derive from the original URL
    if (isArchiveSite()) {
      const orig = getOriginalUrl();
      if (orig) {
        try { return hostnameToPublication(new URL(orig).hostname); } catch (e) { /* fall through */ }
      }
    }

    // Normal site: use the current hostname
    return hostnameToPublication(location.hostname);
  }

  /** Best-effort headline extraction */
  function getHeadline() {
    // Prefer <h1> inside article content
    const h1s = document.querySelectorAll('h1');
    for (const h1 of h1s) {
      // Skip elements inside archive.is chrome or nav
      if (h1.closest('#HEADER, #DIVSHARE, nav, [role="banner"], [role="navigation"]')) continue;
      const text = h1.textContent.trim();
      if (text.length > 10) return text;
    }

    // Try <meta property="og:title">
    const ogTitle = document.querySelector('meta[property="og:title"]');
    if (ogTitle) {
      const content = ogTitle.getAttribute('content')?.trim();
      if (content && content.length > 10) {
        return content.replace(/\s*[|\u2013\u2014]\s*[^|\u2013\u2014]*$/, '').trim();
      }
    }

    // Fallback: <title> with publication suffix stripped
    const title = document.title;
    return title.replace(/\s*[|\u2013\u2014-]\s*[^|\u2013\u2014-]*$/, '').trim() || title;
  }

  /**
   * Normalize editorial abbreviations before slugifying.
   * NYT style uses "A.I." which would otherwise slugify to "a-i" and then
   * collapse to "i" once "a" is stripped as a stop word. Expand known
   * initialisms to their full slug-friendly form.
   */
  function normalizeAbbreviations(text) {
    return text
      .replace(/\bA\.I\.\b/gi, 'AI')
      .replace(/\bU\.S\.A\.\b/gi, 'USA')
      .replace(/\bU\.S\.\b/gi, 'US')
      .replace(/\bU\.K\.\b/gi, 'UK')
      .replace(/\bE\.U\.\b/gi, 'EU')
      .replace(/\bD\.C\.\b/gi, 'DC')
      .replace(/\bC\.E\.O\.\b/gi, 'CEO')
      .replace(/\bC\.T\.O\.\b/gi, 'CTO')
      .replace(/\bN\.Y\.\b/gi, 'NY')
      .replace(/\bL\.A\.\b/gi, 'LA');
  }

  /** Turn a headline string into a URL-safe slug */
  function slugify(text) {
    return normalizeAbbreviations(text)
      .toLowerCase()
      .replace(/[''\u2018\u2019\u2032\u00b4`]/g, '')        // remove apostrophes / quotes
      .replace(/[^a-z0-9\s-]/g, ' ')                          // non-alphanumeric → space
      .split(/\s+/)
      .filter(w => w.length > 0 && !STOP_WORDS.has(w))
      .join('-')
      .replace(/-{2,}/g, '-')
      .replace(/^-|-$/g, '');
  }

  /** Build the clean PDF filename (without extension) */
  function generateFilename() {
    const publication = getPublication();
    const headline = getHeadline();
    const slug = slugify(headline);

    if (publication && slug) return `${publication}-${slug}`;
    return slug || publication || 'print';
  }

  // =========================================================
  // Floating-element cleanup
  // =========================================================

  let markedElements = [];

  /** Scan the DOM for fixed / sticky elements and mark them for hiding */
  function hideFloatingElements() {
    markedElements = [];
    const viewportArea = window.innerWidth * window.innerHeight;

    const all = document.querySelectorAll('*');
    for (let i = 0; i < all.length; i++) {
      const el = all[i];
      if (el === document.documentElement || el === document.body) continue;

      let pos;
      try { pos = getComputedStyle(el).position; } catch (e) { continue; }

      if (pos !== 'fixed' && pos !== 'sticky') continue;

      // Skip elements that are basically the whole page (some sites wrap
      // everything in a fixed container for scroll effects)
      const rect = el.getBoundingClientRect();
      if (rect.width * rect.height > viewportArea * 0.75) continue;

      el.classList.add('pdf-archiver-hide');
      markedElements.push(el);
    }

    // Archive.is specific IDs (belt + suspenders with the CSS rules)
    if (isArchiveSite()) {
      document.querySelectorAll('#HEADER, #DIVSHARE').forEach(el => {
        if (!el.classList.contains('pdf-archiver-hide')) {
          el.classList.add('pdf-archiver-hide');
          markedElements.push(el);
        }
      });
    }
  }

  /** Remove the hide markers so the page returns to normal */
  function restoreFloatingElements() {
    for (const el of markedElements) {
      el.classList.remove('pdf-archiver-hide');
    }
    markedElements = [];
  }

  // =========================================================
  // Print lifecycle
  // =========================================================

  let originalTitle = '';
  let printActive = false;

  function prepareForPrint() {
    if (printActive) return;
    printActive = true;

    // Set a clean filename (Chrome uses document.title as the PDF name)
    originalTitle = document.title;
    document.title = generateFilename();

    // Hide floating junk
    hideFloatingElements();
  }

  function cleanupAfterPrint() {
    if (!printActive) return;

    restoreFloatingElements();

    // Restore the title after a short delay so Chrome has already grabbed it
    setTimeout(() => {
      document.title = originalTitle;
      printActive = false;
    }, 500);
  }

  // beforeprint / afterprint fire for ALL print paths: Ctrl+P, right-click → Print,
  // window.print(), File → Print, and the toolbar button.
  window.addEventListener('beforeprint', prepareForPrint);
  window.addEventListener('afterprint', cleanupAfterPrint);

  // =========================================================
  // Toolbar-button message handler
  // =========================================================

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.action === 'print') {
      window.print();          // triggers beforeprint → print dialog → afterprint
      sendResponse({ ok: true });
    }
  });
})();
